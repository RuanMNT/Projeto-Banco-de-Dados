package br.com.sinform.empresa.controller;


import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import br.com.sinform.empresa.model.Categoria;
import br.com.sinform.empresa.repository.CategoriasRepository;


@Controller
@RequestMapping("/categorias")
public class CategoriasController {

	@Autowired
	private CategoriasRepository categoriasRepository;
	
	@GetMapping("/novo")
	public ModelAndView novo(){
		ModelAndView mv = new ModelAndView ("CadastroCategoria");
		
		mv.addObject(new Categoria());
	
		return mv; 
	}
	
	@GetMapping
	public ModelAndView listar(){
		List<Categoria> categorias = categoriasRepository.findAll();
		ModelAndView mv = new ModelAndView("ListaCategorias");
		mv.addObject("categorias", categorias);
		
		return mv;
	}
	
	@ModelAttribute(name="categorias")
	public List<Categoria> Categorias(){
		return categoriasRepository.findAll();
	}

	
	@RequestMapping(method=RequestMethod.POST)
	public String salvar(Categoria categoria) {
		System.out.println(categoria.getId() + "|" + categoria.getNome() + "|" + categoria.getDescricao());
		categoriasRepository.save(categoria);
		return "redirect:/categorias/novo";
	}
	
	@RequestMapping("{id}")
	public ModelAndView edicao(@PathVariable("id") Categoria categoria) {
		ModelAndView mv = new ModelAndView("CadastroCategoria");
		mv.addObject(categoria);
		return mv;
	}
	
	@RequestMapping(value="{id}", method=RequestMethod.DELETE)
	public String excluir(@PathVariable Long id) {
		categoriasRepository.delete(id);
		return "redirect:/categorias";
	}

}
