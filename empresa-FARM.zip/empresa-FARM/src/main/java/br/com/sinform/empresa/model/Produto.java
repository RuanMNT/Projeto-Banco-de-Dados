package br.com.sinform.empresa.model;

import java.math.BigDecimal;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.format.annotation.NumberFormat;

@Entity
@Table(name = "produtos")
public class Produto {
	@Id
	@GeneratedValue
	private Long id;
	@Column(unique = true)
	private String nome;
	private String codigointerno;
	private Long codigodebarras;
	private String substancia;
	@DateTimeFormat(pattern = "dd/MM/yyyy")
	@Temporal(TemporalType.DATE)
	private Date validade;
	@NumberFormat(pattern = "#,##0.00")
	private BigDecimal preco;
	@NumberFormat(pattern = "#,##0.00")
	private BigDecimal desconto;
	@ManyToOne
	@JoinColumn(name = "categoria_id")
	private Categoria categoria;
	@Enumerated(EnumType.STRING)
	@Column(name = "referencias")
	private Referencia referencia;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getCodigointerno() {
		return codigointerno;
	}

	public void setCodigointerno(String codigointerno) {
		this.codigointerno = codigointerno;
	}

	public Long getCodigodebarras() {
		return codigodebarras;
	}

	public void setCodigodebarras(Long codigodebarras) {
		this.codigodebarras = codigodebarras;
	}

	public String getSubstancia() {
		return substancia;
	}

	public void setSubstancia(String substancia) {
		this.substancia = substancia;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public Date getValidade() {
		return validade;
	}

	public void setValidade(Date validade) {
		this.validade = validade;
	}

	public BigDecimal getPreco() {
		return preco;
	}

	public void setPreco(BigDecimal preco) {
		this.preco = preco;
	}

	public Categoria getCategoria() {
		return categoria;
	}

	public void setCategoria(Categoria categoria) {
		this.categoria = categoria;
	}

	public Referencia getReferencia() {
		return referencia;
	}

	public void setReferencia(Referencia referencia) {
		this.referencia = referencia;
	}

	public BigDecimal getDesconto() {
		return desconto;
	}

	public void setDesconto(BigDecimal desconto) {
		this.desconto = desconto;
	}

}
