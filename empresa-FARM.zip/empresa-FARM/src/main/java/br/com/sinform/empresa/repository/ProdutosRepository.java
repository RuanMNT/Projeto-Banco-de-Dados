package br.com.sinform.empresa.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import br.com.sinform.empresa.model.Produto;

public interface ProdutosRepository extends JpaRepository <Produto, Long> {
	
	

}
