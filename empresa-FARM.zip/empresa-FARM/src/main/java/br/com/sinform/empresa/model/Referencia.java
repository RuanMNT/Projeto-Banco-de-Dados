package br.com.sinform.empresa.model;

public enum Referencia {
	GENERICO("Genérico"), SIMILAR("Similar"), ETICO("Ético");
	
	private String descricao;

	Referencia(String descricao) {
		this.descricao = descricao;
	}

	public String getDescricao() {
		return descricao;
	
	}
}
