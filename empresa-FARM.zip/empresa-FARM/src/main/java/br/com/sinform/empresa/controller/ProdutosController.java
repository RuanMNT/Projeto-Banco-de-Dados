package br.com.sinform.empresa.controller;

import java.util.Arrays;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import br.com.sinform.empresa.model.Categoria;
import br.com.sinform.empresa.model.Produto;
import br.com.sinform.empresa.model.Referencia;
import br.com.sinform.empresa.repository.CategoriasRepository;
import br.com.sinform.empresa.repository.ProdutosRepository;

@Controller
@RequestMapping("/produtos")
public class ProdutosController {
	@Autowired
	private ProdutosRepository produtosRepository;
	@Autowired
	private CategoriasRepository categoriasRepository;

	@GetMapping("/novo")
	public ModelAndView novo() {
		ModelAndView mv = new ModelAndView("CadastroProduto");
		mv.addObject(new Produto());
		return mv;
	}
	
	@GetMapping
	public ModelAndView listar() {
		List<Produto> produto = produtosRepository.findAll();
		ModelAndView mv = new ModelAndView("ListaProdutos");
		mv.addObject("produtos", produto);

		return mv;
	}
	
	@ModelAttribute(name = "categorias")
	public List<Categoria> categorias() {
		return categoriasRepository.findAll();
	}

	@ModelAttribute(name = "referenciaList")
	public List<Referencia> referenciaList() {
		return Arrays.asList(Referencia.values());
	}

	@RequestMapping(method = RequestMethod.POST)
	public String salvar(Produto produto) {
		if (produto.getCategoria() == null || produto.getClass() == null || produto.getCodigodebarras() == null) {
			
		}
		produtosRepository.save(produto);
		return "redirect:/produtos/novo";
	}
		
	@RequestMapping("{id}")
	public ModelAndView edicao(@PathVariable("id") Produto produto) {
		ModelAndView mv = new ModelAndView("CadastroProduto");
		mv.addObject(produto);
		return mv;
	}
	@RequestMapping(value="{id}",method=RequestMethod.DELETE)
	public String excluir(@PathVariable Long id) {
		produtosRepository.delete(id);
		return "redirect:/produtos";
		
	}
}
