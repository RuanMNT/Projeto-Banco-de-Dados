package br.com.sinform.empresa.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import br.com.sinform.empresa.model.Categoria;

public interface CategoriasRepository extends JpaRepository<Categoria, Long>{
	
	

}
