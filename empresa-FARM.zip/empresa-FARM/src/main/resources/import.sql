insert into categorias (nome) values ('Higiene pessoal');
insert into categorias (nome) values ('Medicamentos');
insert into categorias (nome) values ('Medicamentos Controlados');
insert into categorias (nome) values ('Outros');
