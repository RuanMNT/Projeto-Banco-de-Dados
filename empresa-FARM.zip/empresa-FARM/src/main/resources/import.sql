insert into categorias (id,nome) values (1,'Higiene pessoal');
insert into categorias (id,nome) values (2,'Cosmética');
insert into categorias (id,nome) values (3,'Medicamentos');
insert into categorias (id,nome) values (4,'Medicamentos Controlados');
insert into categorias (id,nome) values (5,'Outros');